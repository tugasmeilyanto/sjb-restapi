package dto

import (
	"sjb-restapi/entity"
)

type ResponseProduct struct {
	ResponseCode 	int				`json:"response_code"`
	ResponseMessage string			`json:"response_message"`
	Data 			[]entity.Product	`json:"data"`
}