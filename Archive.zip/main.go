package main

import (
	"net/http"
	"sjb-restapi/handler"
	"fmt"
)

func main() {
	http.HandleFunc("/products", handler.GetProduct)
	http.HandleFunc("/product", handler.AddProduct)


	fmt.Println("Server is running on port :8080")
	err := http.ListenAndServe(":8080", nil)
	if err != nil{
		fmt.Println(err)
	}

	//nil -> value yang kosong
	//int -> 0
	//string -> ""
	//null
}